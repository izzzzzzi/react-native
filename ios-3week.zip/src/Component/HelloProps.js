import React from "react";
import "../App.css";

const HelloProps = (props) => {
  return <p>Hi My name is {props.name}.</p>;
};

export default HelloProps;
